
def list_startup_programs():
    """List all startup programs."""
    print("Startup programs listing not implemented yet.")

def disable_startup_program(name):
    """Disable a startup program by name."""
    print(f"Disable startup program {name} not implemented yet.")